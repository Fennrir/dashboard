// Requirements
const express = require('express')
const ejs = require('ejs')
const app = express()

// Set up
app.set('view engine', 'ejs')
app.use(express.static('public'))


// Paths
app.get('/', (req, res) => {
    res.render('index')
})

app.get('/apie', (req, res) => {
    res.render('about')
})

app.get('/kontaktai', (req, res) => {
    res.render('contacts')
})

app.get('/galerija', (req, res) => {
    res.render('galery')
})



// Run server
app.listen(process.env.PORT, process.env.IP, function(){
    console.log('Listening on port:', process.env.PORT, '...')
})